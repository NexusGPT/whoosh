Press kit, fixture sample.
